// ============================================================================
// Agnes Herbal Supplements — SEO helpers zinazotumiwa na Cloudflare Pages
// Functions (functions/products/[slug].js, functions/img/custom/[id]/[idx].js,
// functions/sitemap-products-live.xml.js).
//
// KUSUDI: bidhaa 288 za awali zina kurasa tuli za SEO (products/pX-jina.html)
// zilizotengenezwa mara moja. Bidhaa MPYA anazoongeza admin kwenye "➕ Ongeza
// Bidhaa" huhifadhiwa Firestore (customProducts) TU — hazina ukurasa wa SEO
// wala picha zenye URL ya kweli (picha zake zimehifadhiwa kama base64 ndani
// ya hati ya Firestore, si Firebase Storage, kwa sababu Storage inahitaji
// mpango wa kulipa Blaze — ona js/firebase-config.js).
//
// Functions hizi zinasoma moja kwa moja kutoka Firestore REST API (bila
// funguo ya siri — collection hii ni "read: if true" kwenye firestore.rules,
// yaani tayari ni ya wazi kwa umma) na:
//   1) kutengeneza ukurasa kamili wa SEO wa kila bidhaa mpya papo kwa papo
//      (bila kuhitaji "build step" yoyote — Cloudflare Pages Functions
//      zinaendesha wakati ombi linapofika, ndani ya zip ile ile ya deploy),
//   2) kutoa picha za bidhaa hizo kama URL za kweli zinazoweza kutambulika
//      na Google (badala ya base64 iliyofichwa ndani ya JSON),
//   3) kutengeneza sitemap ya pili yenye orodha ya bidhaa hizi zote mpya.
// ============================================================================

export const PROJECT_ID = 'agnes-1-console';
export const SITE = 'https://agnesherbalsupplements.com';
export const FIRESTORE_BASE = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents`;
export const WHATSAPP_NUMBER = '255678883675';
// IndexNow (Bing, Yandex...): faili la ufunguo liko kwenye mzizi wa tovuti: /<ufunguo>.txt
export const INDEXNOW_KEY = 'bc647de973740d7df77bf5fd9c824709';

export function slugify(s) {
  return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
}

export function escapeHtml(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}

export function escapeXml(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[ch]));
}

// ---------------------------------------------------------------------------
// Firestore REST API inarudisha kila thamani ikiwa imefungwa kwa aina yake
// (mfano {"stringValue":"Womb Tea"}). Hii inaibadilisha kuwa JS ya kawaida.
// ---------------------------------------------------------------------------
function fsValue(v) {
  if (v == null) return null;
  if ('stringValue' in v) return v.stringValue;
  if ('integerValue' in v) return parseInt(v.integerValue, 10);
  if ('doubleValue' in v) return v.doubleValue;
  if ('booleanValue' in v) return v.booleanValue;
  if ('nullValue' in v) return null;
  if ('timestampValue' in v) return v.timestampValue;
  if ('arrayValue' in v) return (v.arrayValue.values || []).map(fsValue);
  if ('mapValue' in v) return fsDoc({ fields: (v.mapValue && v.mapValue.fields) || {} });
  return null;
}
export function fsDoc(doc) {
  const out = {};
  const fields = (doc && doc.fields) || {};
  for (const k in fields) out[k] = fsValue(fields[k]);
  return out;
}

// Inasoma productOverrides ZOTE (admin.html → "Hariri Bidhaa": jina/bei/
// caption/picha zinazobadilishwa BAADA ya bidhaa kuundwa). Kabla ya
// marekebisho haya, SSR ya Google ilikuwa inasoma customProducts TU — hivyo
// mabadiliko ya admin (mfano jina jipya fupi kwa ajili ya Google) hayakuwa
// yakimfikia Google kamwe, japo yalionekana dukani kwa mteja mara moja.
// Orodha NYEPESI (bila picha/video za base64): ukurasa wa bidhaa unahitaji tu jina/slug/bei/maelezo
// ya bidhaa ZOTE (kwa kuangalia slug na "Bidhaa Zinazohusiana"). Picha na video za bidhaa
// iliyoombwa tu hupakuliwa kwa fetchCustomProductById(). Bila hili, kila ukurasa ulikuwa
// unapakua MB 17+ za picha za bidhaa zote.
const LITE_FIELDS = ['id','name','slug','category','catSlug','prices','caption','effect','stock','dateAdded',
  'benefits','faq','videoId','rating','reviewCount','seoTitle','metaDescription','imageAlt','bestseller','prefix','hidden'];
const LITE_MASK = LITE_FIELDS.map(f => '&mask.fieldPaths=' + encodeURIComponent(f)).join('');

async function fetchAllOverrides(lite) {
  const map = {};
  let pageToken = '';
  for (let i = 0; i < 10; i++) {
    const url = `${FIRESTORE_BASE}/productOverrides?pageSize=300${lite ? LITE_MASK : ''}${pageToken ? '&pageToken=' + encodeURIComponent(pageToken) : ''}`;
    const res = await fetch(url);
    if (!res.ok) break;
    const data = await res.json();
    (data.documents || []).forEach(d => { map[d.name.split('/').pop()] = fsDoc(d); });
    if (!data.nextPageToken) break;
    pageToken = data.nextPageToken;
  }
  return map;
}
// Picha ya "Profaili" (cover) iliyochaguliwa na admin inakuwa ya KWANZA (ndiyo inayotumika kwa og:image, ukurasa na Google).
function coverFirst(images, cover) {
  if (!Array.isArray(images) || !cover) return images;
  const i = images.indexOf(cover);
  return i > 0 ? [cover, ...images.slice(0, i), ...images.slice(i + 1)] : images;
}
function mergeOverride(product, ov) {
  if (!ov) return product;
  const merged = mergeOverrideRaw(product, ov);
  merged.images = coverFirst(merged.images, merged.cover);
  return merged;
}
function mergeOverrideRaw(product, ov) {
  return {
    ...product,
    name: ov.name || product.name,
    // Bei, stock na "ficha" kutoka Admin → Hariri Bidhaa (productOverrides) sasa zinafika kwenye ukurasa wa bidhaa moja kwa moja.
    prices: (ov.prices && ov.prices.retail) ? ov.prices : product.prices,
    stock: (typeof ov.stock === 'number') ? ov.stock : product.stock,
    hidden: (typeof ov.hidden === 'boolean') ? ov.hidden : !!product.hidden,
    caption: ov.caption || product.caption,
    cover: ov.cover || product.cover,
    images: (ov.images && ov.images.length) ? ov.images : product.images,
    videoClip: ov.videoClip || product.videoClip,
    videoId: ov.videoId || product.videoId,
    seoTitle: ov.seoTitle || product.seoTitle,
    metaDescription: ov.metaDescription || product.metaDescription,
    imageAlt: ov.imageAlt || product.imageAlt,
    slug: ov.slug || product.slug,
    benefits: (ov.benefits && ov.benefits.length) ? ov.benefits : product.benefits,
    faq: (ov.faq && ov.faq.length) ? ov.faq : product.faq,
  };
}

// Inasoma customProducts ZOTE (kurasa nyingi ikihitajika), kisha inaunganisha
// (merge) na productOverrides ya kila bidhaa — ili jina/picha/caption ULIYOBADILISHA
// kwenye admin BAADA ya kuunda bidhaa ionekane kwa Google 100%, sio dukani tu.
export async function fetchCustomProducts(lite) {
  let all = [];
  let pageToken = '';
  for (let i = 0; i < 10; i++) {
    const url = `${FIRESTORE_BASE}/customProducts?pageSize=300${lite ? LITE_MASK : ''}${pageToken ? '&pageToken=' + encodeURIComponent(pageToken) : ''}`;
    const res = await fetch(url);
    // Ukurasa wa KWANZA ukishindwa = Firestore haipatikani: tupa kosa ili wito (mf. /products/:slug) utoe 503,
    // si orodha tupu inayosababisha 404 ya uongo kwa bidhaa halali.
    if (!res.ok) { if (i === 0) throw new Error('Firestore ' + res.status); break; }
    const data = await res.json();
    const docs = (data.documents || []).map(d => {
      const obj = fsDoc(d);
      obj._docId = d.name.split('/').pop();
      return obj;
    });
    all = all.concat(docs);
    if (!data.nextPageToken) break;
    pageToken = data.nextPageToken;
  }
  return mergeAllOverrides(all, lite);
}
async function mergeAllOverrides(all, lite) {
  let overrides = {};
  try { overrides = await fetchAllOverrides(lite); } catch (e) { /* SSR isiharibike ikiwa hii pekee itashindikana */ }
  return all.map(p => mergeOverride(p, overrides[p._docId] || overrides[String(p.id)]));
}

export async function fetchCustomProductById(id) {
  const res = await fetch(`${FIRESTORE_BASE}/customProducts/${encodeURIComponent(String(id))}`);
  if (!res.ok) return null;
  const doc = await res.json();
  if (!doc || !doc.fields) return null;
  const obj = fsDoc(doc);
  obj._docId = String(id);
  let ov = null;
  try {
    const ovRes = await fetch(`${FIRESTORE_BASE}/productOverrides/${encodeURIComponent(String(id))}`);
    if (ovRes.ok) ov = fsDoc(await ovRes.json());
  } catch (e) { /* endelea bila override ikiwa fetch hii itashindikana */ }
  return mergeOverride(obj, ov);
}

// Override ya bidhaa MOJA (kwa bidhaa 288 za awali: jina/bei/picha/maelezo/stock/ficha zilizobadilishwa kwenye admin).
// Inarudisha null ikiwa hakuna override au Firestore imeshindwa (ukurasa tuli unaendelea kutumika).
export async function fetchOverrideById(id) {
  try {
    const res = await fetch(`${FIRESTORE_BASE}/productOverrides/${encodeURIComponent(String(id))}`);
    if (!res.ok) return null;
    const doc = await res.json();
    return (doc && doc.fields) ? fsDoc(doc) : null;
  } catch (e) { return null; }
}

export function productSlug(p) {
  // Muundo mmoja kwa bidhaa ZOTE: p<namba>-<jina>  (mfano p0-28-day-slimming-tea).
  // Slug ya admin inayoanza na namba (mfano "100100-fertility-combo") inapewa "p" mbele.
  const custom = slugify(p.slug || '');
  if (custom) return /^\d+-/.test(custom) ? `p${custom}` : custom;
  const byName = slugify(p.name);
  return byName ? `p${p.id}-${byName}` : `bidhaa-${p.id}`;
}

// Alama fupi inayobadilika picha ikibadilika: URL mpya => hakuna picha ya zamani kwenye cache ya kivinjari/CDN/Facebook.
export function imageVersion(img) {
  const t = String(img || ''); let h = 0;
  for (let i = 0; i < t.length; i += 97) h = (h * 31 + t.charCodeAt(i)) >>> 0;
  return (h + t.length).toString(36);
}
// Picha ya admin inaweza kuwa data-URL (base64), kiungo kamili (https://...) au njia ya faili ya tovuti ("images/p282.jpg").
// Data-URL pekee ndiyo inayopitia /img/custom/; nyingine zinatumika moja kwa moja (vinginevyo proxy hurudisha 404 na picha haionekani kwenye share).
export function directImageUrl(img) {
  const t = String(img || '').trim();
  if (!t || /^data:/i.test(t)) return null;
  if (/^https?:\/\//i.test(t)) return t;
  return `${SITE}/${t.replace(/^\.?\/+/, '')}`;
}
export function imageProxyUrl(productId, index, img) {
  const direct = directImageUrl(img);
  if (direct) return direct;
  return `${SITE}/img/custom/${productId}/${index}.jpg${img ? '?v=' + imageVersion(img) : ''}`;
}

// Video HALISI (videoClip) admin aliyopakia kwenye "Ongeza Bidhaa" imehifadhiwa
// kama base64 ndani ya hati ya Firestore (sawa na picha — hakuna Storage ya
// kulipa). Sawa na imageProxyUrl juu, hii inatoa URL ya kweli inayoweza
// kutambulika/kupakuliwa na Google kupitia functions/video/custom/[id].js.
export function videoProxyUrl(productId) {
  return `${SITE}/video/custom/${productId}.webm`;
}

// ALT text: Jina + Kazi/Faida (ikiwa tofauti na jina) + "Tanzania" — sawa na
// mfumo unaotumika kwenye bidhaa 288 za awali. Alama kama "–" na "&"
// zinasafishwa, na maneno yanayorudiwa (mfano jina na kazi zikiwa na neno
// moja) yanaondolewa ili isiwe ni "keyword stuffing".
export function buildAltText(p) {
  if (p.imageAlt && p.imageAlt.trim()) return p.imageAlt.trim().slice(0, 160);
  const clean = s => String(s || '').replace(/[–—]/g, ' ').replace(/&/g, 'na').replace(/\s+/g, ' ').trim();
  const name = clean(p.name);
  const effect = clean(p.effect);
  const parts = [name];
  if (effect && effect.toLowerCase() !== name.toLowerCase()) parts.push(effect);
  parts.push('Tanzania');

  const seen = new Set();
  const words = [];
  parts.join(' ').split(' ').forEach(w => {
    const key = w.toLowerCase();
    if (!key || seen.has(key)) return;
    seen.add(key);
    words.push(w);
  });
  return words.join(' ').slice(0, 160);
}

export function buildTitle(p) {
  if (p.seoTitle && p.seoTitle.trim()) return p.seoTitle.trim();
  return `${p.name} | Agnes Herbal Supplements Tanzania`;
}

// Meta description: admin override kwanza (ikiwa ipo), kisha caption ya
// admin (imefupishwa), la sivyo muundo ule ule unaotumika kwenye kurasa
// 288 za awali.
export function buildMetaDescription(p) {
  if (p.metaDescription && p.metaDescription.trim()) {
    const custom = p.metaDescription.trim();
    return custom.length > 158 ? custom.slice(0, 157).trim() + '…' : custom;
  }
  let base = (p.caption && p.caption.trim())
    ? p.caption.trim()
    : `${p.name} - ${p.effect || p.category} - ${p.category}.`;
  if (!/agnes herbal/i.test(base)) {
    base += ' Bidhaa ya asili kutoka Agnes Herbal Supplements, Tanzania.';
  }
  base = base.replace(/\s+/g, ' ').trim();
  return base.length > 158 ? base.slice(0, 157).trim() + '…' : base;
}


// Maswali ya kawaida ya duka (sera za duka, si madai ya kiafya) — yanatumika kwenye kila ukurasa wa bidhaa,
// sawa na kurasa tuli. Maswali ya admin (Mipangilio ya SEO) yanatangulia yakiwepo.
export function buildStandardFaq(p) {
  const name = p.name;
  const pr = p.prices || {};
  const fmt = n => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  const items = [
    [`Naagizaje ${name}?`, `Bofya "ORDER NOW" kwenye ukurasa huu, au tuandikie WhatsApp +255 678 883 675. Tunakufikishia Dar es Salaam, mikoani, na pia Kenya, Uganda na Burundi.`]
  ];
  if (pr.w5 && pr.w10 && pr.retail) {
    items.push([`Bei ya jumla (wholesale) ya ${name} ni ngapi?`, `Rejareja ni Tsh ${fmt(pr.retail)}. Ukinunua vipande 5 au zaidi ni Tsh ${fmt(pr.w5)} kwa kimoja, na vipande 10 au zaidi ni Tsh ${fmt(pr.w10)} kwa kimoja.`]);
  }
  items.push(['Nawezaje kulipa?', 'Tunapokea M-Pesa, Mixx by Yas, HaloPesa na NMB. Maelezo kamili yako kwenye ukurasa wa Uwasilishaji na Malipo.']);
  items.push(['Naweza kuuliza kabla ya kuagiza?', 'Ndiyo. Tuandikie WhatsApp +255 678 883 675 na tutakujibu kuhusu matumizi, upatikanaji na usafirishaji.']);
  return items.map(([q, a]) => ({ q, a }));
}
