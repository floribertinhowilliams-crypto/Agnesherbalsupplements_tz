// Route: /img/hero/:id  (mf. /img/hero/k3x9a2.jpg?v=1730000000000)
// Picha za slaidi za mwanzo zinahifadhiwa na admin kama data URL ndani ya hati ya Firestore
// (meta/heroImg_<id>). Function hii inazirudisha kama picha halisi (bytes) yenye URL thabiti, ili
// zihifadhiwe na CDN/kivinjari (cache ndefu kwa sababu ?v= inabadilika picha ikibadilika).
import { FIRESTORE_BASE, fsDoc } from '../../_lib/seo.js';

export async function onRequestGet(context) {
  const id = String(context.params.id || '').replace(/\.(jpe?g|png|webp)$/i, '');
  if (!/^[a-z0-9]{3,24}$/i.test(id)) return new Response('Not found', { status: 404 });
  let doc;
  try {
    const res = await fetch(`${FIRESTORE_BASE}/meta/heroImg_${id}`);
    if (!res.ok) return new Response('Not found', { status: 404 });
    doc = await res.json();
  } catch (e) { return new Response('Not found', { status: 404 }); }
  const dataUrl = fsDoc(doc).data;
  const m = /^data:(image\/[a-zA-Z0-9.+-]+);base64,([\s\S]+)$/.exec(String(dataUrl || ''));
  if (!m) return new Response('Not found', { status: 404 });
  let bytes;
  try {
    const bin = atob(m[2]);
    bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  } catch (e) { return new Response('Not found', { status: 404 }); }
  const hasV = new URL(context.request.url).searchParams.has('v');
  return new Response(bytes, { status: 200, headers: {
    'Content-Type': m[1],
    'Cache-Control': hasV ? 'public, max-age=31536000, immutable' : 'public, max-age=300',
    'X-Robots-Tag': 'noindex'
  } });
}
export const onRequestHead = onRequestGet;
