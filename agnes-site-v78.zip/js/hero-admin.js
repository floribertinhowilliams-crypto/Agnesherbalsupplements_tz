// Agnes Herbal Supplements — Admin: "🖼 Slaidi za Mwanzo" (hero slider editor)
// ============================================================================
// Admin anaongeza/anahariri/anapanga slaidi zinazopita mwanzoni mwa duka: maandishi, kitufe + kiungo
// (bidhaa maalum au kiungo chochote), rangi ya mandhari, mtindo wa kuingia/kutoka kwa kila slaidi, na
// PICHA (kitufe cha kubadilisha). Inahifadhi Firestore: meta/heroSlider + meta/heroImg_<id>.
// Duka linapokea mabadiliko papo hapo (js/hero-slides.js).
(function () {
  'use strict';
  var MAX_SLIDES = 12;
  var THEMES = [['wine', 'Nyekundu ya divai', 'linear-gradient(135deg,#7a0f1e,#2a0810,#000)', '#fff'], ['green', 'Kijani kiza', 'radial-gradient(circle at 70% 50%,#143a24,#06120c)', '#fff'], ['rose', 'Waridi (nyepesi)', 'linear-gradient(135deg,#ffe3ee,#fff,#ffd9e8)', '#1a5d1a'], ['gold', 'Dhahabu', 'linear-gradient(135deg,#8a5a00,#3b2600,#120b00)', '#fff'], ['night', 'Bluu ya usiku', 'linear-gradient(135deg,#12306b,#0a1a3d,#030814)', '#fff'], ['purple', 'Zambarau', 'linear-gradient(135deg,#5b1f8a,#26093f,#0b0215)', '#fff'], ['leaf', 'Kijani angavu', 'linear-gradient(135deg,#2f9e44,#12562a,#04200d)', '#fff']];
  var EFFECTS = [['mix', '🎲 Mchanganyiko (zote kwa zamu)'], ['slide', '↔️ Kushoto / Kulia'], ['zoomIn', '🔍 Zoom ndani'], ['zoomOut', '🔎 Zoom nje'], ['rise', '⬆️ Kupanda juu'], ['flip', '🔄 Kugeuka'], ['fade', '🌫 Kufifia']];
  var hsa = { cfg: null, pending: {}, removed: [], open: -1, loaded: false, busy: false };

  function E(s) { return (typeof escapeHtmlA === 'function') ? escapeHtmlA(s) : String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function rid() { return Math.random().toString(36).slice(2, 10); }
  function blank() {
    return { id: rid(), on: true, layout: 'product', theme: 'wine', fx: 'auto', tag: '', white: '', gold: '', text: '', btn: '', linkType: 'product', link: '', img: '', imgv: 0, img2: '', img2v: 0, imgUrl: '', img2Url: '' };
  }
  function seedDefaults() {
    return [
      Object.assign(blank(), { tag: '🔥 Maarufu Sana', white: 'APPLE CIDER VINEGAR', gold: 'GUMMIES', text: 'Kirutubisho cha kila siku chenye ladha nzuri. Tunatuma Tanzania na nje ya nchi.', btn: 'AGIZA SASA Tsh 55,000 →', linkType: 'product', link: '86', theme: 'wine', imgUrl: 'images/p087.jpg', img2Url: 'images/p273.jpg' }),
      Object.assign(blank(), { tag: '✨ Wanawake 25–45', white: "NGOZI YENYE MNG'AO", gold: 'Glutathione + Collagen', text: 'Gummies za Glutathione na Collagen kwa utunzaji wa ngozi na nywele kila siku.', btn: 'ONA GLUTATHIONE →', linkType: 'product', link: '92', theme: 'rose', imgUrl: 'images/p093.jpg', img2Url: 'images/p089.jpg' }),
      Object.assign(blank(), { tag: '🚚 Usafirishaji', white: 'TUNAFIKISHA NCHI 8', gold: 'ZA AFRIKA MASHARIKI', text: 'Tuma WhatsApp tukuthibitishie gharama.', btn: 'ANGALIA USAFIRISHAJI →', linkType: 'url', link: '/delivery-information/', theme: 'green' })
    ];
  }
  function imgSrc(sl, which) {
    var id = which === 2 ? sl.img2 : sl.img, v = which === 2 ? sl.img2v : sl.imgv, u = which === 2 ? sl.img2Url : sl.imgUrl;
    if (id && hsa.pending[id]) return hsa.pending[id];
    if (id) return '/img/hero/' + encodeURIComponent(id) + '.jpg?v=' + (v || 0);
    return u ? '/' + String(u).replace(/^\/+/, '') : '';
  }
  function themeOf(k) { for (var i = 0; i < THEMES.length; i++) if (THEMES[i][0] === k) return THEMES[i]; return THEMES[0]; }
  function status(msg, color) { var s = document.getElementById('hsaStatus'); if (s) { s.style.display = msg ? 'block' : 'none'; s.style.color = color || 'var(--ink-soft)'; s.textContent = msg || ''; } }

  /* ---------- kuonyesha tab ---------- */
  window.renderSlaidiTab = async function renderSlaidiTab() {
    var el = document.getElementById('tab-slaidi');
    if (!el) return;
    if (!hsa.loaded) {
      el.innerHTML = '<p style="padding:20px;">⏳ Inapakia slaidi...</p>';
      var cfg = null;
      try { cfg = (typeof cloudGetHeroSlider === 'function') ? await cloudGetHeroSlider() : null; } catch (e) { cfg = null; }
      hsa.cfg = cfg ? { enabled: cfg.enabled !== false, effect: cfg.effect || 'mix', interval: cfg.interval || 6, slides: (cfg.slides || []).map(function (s) { return Object.assign(blank(), s); }) } : { enabled: true, effect: 'mix', interval: 6, slides: [] };
      hsa.loaded = true;
    }
    draw();
  };
  function draw() {
    var el = document.getElementById('tab-slaidi'); if (!el) return;
    var c = hsa.cfg;
    var list = c.slides.map(function (s, i) { return card(s, i); }).join('') || '<p style="color:var(--ink-soft); padding:12px 0;">Bado hakuna slaidi zako. Bonyeza <b>➕ Ongeza slaidi</b> au <b>📥 Anza na slaidi 3 za sasa</b>. Ukiwa huna slaidi, slaidi 3 za kawaida za duka zinaonekana.</p>';
    el.innerHTML =
      '<h2 style="color:var(--green-deep); margin-bottom:6px; font-family:\'Fraunces\',serif;">🖼 Slaidi za Mwanzo (Hero)</h2>' +
      '<p style="font-size:.82rem; color:var(--ink-soft); margin-bottom:14px;">Hizi ndizo slaidi zinazopita mwanzoni mwa duka. Ongeza hadi ' + MAX_SLIDES + ', badilisha picha, maandishi, kiungo na mtindo wa kupita. Baada ya kubadilisha, bonyeza <b>💾 Hifadhi</b> — wateja wanaona papo hapo.</p>' +
      '<div style="background:#fff; border:1px solid #e4dcc8; border-radius:12px; padding:14px; margin-bottom:14px; display:grid; gap:12px; grid-template-columns:repeat(auto-fit,minmax(210px,1fr));">' +
        '<label style="font-size:.8rem; font-weight:700;">Mtindo wa kupita (kwa slaidi zote)<select class="hsa-in" onchange="hsaCfg(\'effect\',this.value)">' + EFFECTS.map(function (e) { return '<option value="' + e[0] + '"' + (c.effect === e[0] ? ' selected' : '') + '>' + e[1] + '</option>'; }).join('') + '</select></label>' +
        '<label style="font-size:.8rem; font-weight:700;">Kasi: sekunde <b id="hsaSecLbl">' + c.interval + '</b> kila slaidi<input type="range" min="3" max="15" step="1" value="' + c.interval + '" oninput="hsaCfg(\'interval\',+this.value); document.getElementById(\'hsaSecLbl\').textContent=this.value;" style="width:100%;"></label>' +
        '<label style="font-size:.8rem; font-weight:700; display:flex; gap:8px; align-items:center;"><input type="checkbox" ' + (c.enabled ? 'checked' : '') + ' onchange="hsaCfg(\'enabled\',this.checked)"> Tumia slaidi zangu<br><span style="font-weight:400; color:var(--ink-soft);">(ukiizima, slaidi 3 za kawaida zinatumika)</span></label>' +
      '</div>' +
      '<div style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:14px;">' +
        '<button class="btn btn-primary" onclick="hsaAdd()">➕ Ongeza slaidi</button>' +
        (c.slides.length ? '' : '<button class="btn btn-ghost" onclick="hsaSeed()">📥 Anza na slaidi 3 za sasa</button>') +
        '<button class="btn btn-primary" style="background:#1a5d1a;" onclick="hsaSave()">💾 Hifadhi na Weka Live</button>' +
        '<a class="btn btn-ghost" href="/" target="_blank" rel="noopener">👁 Angalia duka</a>' +
      '</div>' +
      '<div id="hsaStatus" style="display:none; font-size:.85rem; font-weight:700; margin-bottom:12px;"></div>' +
      '<div id="hsaList">' + list + '</div>' +
      '<style>.hsa-in{width:100%;padding:9px 10px;border:1.5px solid #d9cfb6;border-radius:8px;font:inherit;margin-top:4px;background:#fff;}.hsa-card{background:#fff;border:1.5px solid #e4dcc8;border-radius:12px;margin-bottom:10px;overflow:hidden;}.hsa-card.off{opacity:.55;}.hsa-row{display:flex;gap:10px;align-items:center;padding:10px;}.hsa-thumb{width:96px;height:56px;border-radius:8px;flex:0 0 auto;display:flex;align-items:center;justify-content:center;font-size:.6rem;font-weight:800;overflow:hidden;background-size:cover;position:relative;}.hsa-thumb img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;}.hsa-btns{display:flex;gap:5px;flex-wrap:wrap;margin-left:auto;}.hsa-btns button{border:1.5px solid #d9cfb6;background:#fff;border-radius:8px;padding:6px 9px;font-size:.78rem;cursor:pointer;}.hsa-edit{padding:12px;border-top:1px dashed #d9cfb6;background:#faf7ee;display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));}.hsa-edit label{font-size:.78rem;font-weight:700;}.hsa-full{grid-column:1/-1;}.hsa-imgbox{border:1.5px dashed #bba;border-radius:10px;padding:10px;text-align:center;background:#fff;}.hsa-imgbox img{max-width:100%;max-height:150px;border-radius:8px;display:block;margin:0 auto 8px;}</style>';
  }
  function card(s, i) {
    var th = themeOf(s.theme), src = imgSrc(s, 1);
    var thumb = '<div class="hsa-thumb" style="background:' + th[2] + '; color:' + th[3] + ';">' + (src ? '<img src="' + E(src) + '" alt="">' : E((s.white || 'Slaidi').slice(0, 14))) + '</div>';
    var title = E([s.white, s.gold].filter(Boolean).join(' ') || '(bila kichwa)');
    var open = hsa.open === i;
    return '<div class="hsa-card' + (s.on ? '' : ' off') + '"><div class="hsa-row">' + thumb +
      '<div style="min-width:0;"><div style="font-weight:800; font-size:.9rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">' + (i + 1) + '. ' + title + '</div><div style="font-size:.72rem; color:var(--ink-soft);">' + (s.layout === 'poster' ? '🖼 Bango (picha nzima)' : '🛍 Bidhaa (maandishi + picha)') + (s.on ? '' : ' · imezimwa') + '</div></div>' +
      '<div class="hsa-btns"><button onclick="hsaMove(' + i + ',-1)" title="Juu">⬆️</button><button onclick="hsaMove(' + i + ',1)" title="Chini">⬇️</button><button onclick="hsaToggle(' + i + ')" title="Washa/Zima">' + (s.on ? '👁' : '🚫') + '</button><button onclick="hsaEdit(' + i + ')">' + (open ? '✖ Funga' : '✏️ Hariri') + '</button></div></div>' +
      (open ? editor(s, i) : '') + '</div>';
  }
  function editor(s, i) {
    var poster = s.layout === 'poster';
    var prods = (typeof allAdminProducts === 'function' ? allAdminProducts() : (typeof PRODUCTS !== 'undefined' ? PRODUCTS : [])).slice().sort(function (a, b) { return String(a.name).localeCompare(String(b.name)); });
    var curP = prods.filter(function (p) { return String(p.id) === String(s.link); })[0];
    var img1 = imgSrc(s, 1), img2 = imgSrc(s, 2);
    function f(key, label, ph, type) { return '<label>' + label + '<input class="hsa-in" type="text" value="' + E(s[key] || '') + '" placeholder="' + E(ph || '') + '" oninput="hsaSet(' + i + ',\'' + key + '\',this.value)"></label>'; }
    return '<div class="hsa-edit">' +
      '<label>Aina ya slaidi<select class="hsa-in" onchange="hsaSet(' + i + ',\'layout\',this.value,true)"><option value="product"' + (poster ? '' : ' selected') + '>🛍 Bidhaa — maandishi kushoto, picha kulia</option><option value="poster"' + (poster ? ' selected' : '') + '>🖼 Bango — picha nzima (mf. tangazo/ofa)</option></select></label>' +
      '<label>Rangi ya mandhari<select class="hsa-in" onchange="hsaSet(' + i + ',\'theme\',this.value,true)">' + THEMES.map(function (t) { return '<option value="' + t[0] + '"' + (s.theme === t[0] ? ' selected' : '') + '>' + t[1] + '</option>'; }).join('') + '</select></label>' +
      '<label>Mtindo wa slaidi hii<select class="hsa-in" onchange="hsaSet(' + i + ',\'fx\',this.value)"><option value="auto"' + (s.fx === 'auto' ? ' selected' : '') + '>Fuata mtindo wa jumla</option>' + EFFECTS.filter(function (e) { return e[0] !== 'mix'; }).map(function (e) { return '<option value="' + e[0] + '"' + (s.fx === e[0] ? ' selected' : '') + '>' + e[1] + '</option>'; }).join('') + '</select></label>' +
      f('tag', 'Kibandiko kidogo juu (tag)', '🔥 Ofa Maalum') + f('white', 'Kichwa — mstari 1 (nyeupe)', 'KARIBU OFA YA WIKI') + f('gold', 'Kichwa — mstari 2 (dhahabu)', 'PUNGUZO 20%') +
      '<label class="hsa-full">Maelezo mafupi<textarea class="hsa-in" rows="2" oninput="hsaSet(' + i + ',\'text\',this.value)">' + E(s.text || '') + '</textarea></label>' +
      f('btn', 'Maandishi ya kitufe (acha tupu = hakuna kitufe)', 'AGIZA SASA →') +
      '<label>Kitufe kinaenda wapi?<select class="hsa-in" onchange="hsaSet(' + i + ',\'linkType\',this.value,true)"><option value="product"' + (s.linkType === 'product' ? ' selected' : '') + '>Bidhaa maalum (inafunguka ndani ya duka)</option><option value="url"' + (s.linkType === 'url' ? ' selected' : '') + '>Kiungo / sehemu ya duka</option><option value="none"' + (s.linkType === 'none' ? ' selected' : '') + '>Hakuna</option></select></label>' +
      (s.linkType === 'product' ? '<label class="hsa-full">Chagua bidhaa' + (curP ? ' — sasa: <b>' + E(curP.name) + '</b>' : '') + '<input class="hsa-in" type="search" placeholder="🔎 Tafuta jina la bidhaa..." oninput="hsaFilter(' + i + ',this.value)"><select class="hsa-in" id="hsaProdSel' + i + '" size="5" onchange="hsaSet(' + i + ',\'link\',this.value,true)">' + prodOptions(prods, s.link, '') + '</select></label>' : '') +
      (s.linkType === 'url' ? '<label class="hsa-full">Kiungo (https://..., /je-ipo/, #bidhaa, wa.me/...)<input class="hsa-in" type="text" value="' + E(s.link || '') + '" oninput="hsaSet(' + i + ',\'link\',this.value)"><span style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;">' +
        [['Bidhaa zote', '#bidhaa'], ['Je, ipo?', '/je-ipo/'], ['Usafirishaji', '/delivery-information/'], ['WhatsApp', 'https://wa.me/255678883675']].map(function (p) { return '<button type="button" class="btn btn-ghost" style="padding:5px 10px;font-size:.72rem;" onclick="hsaSet(' + i + ',\'link\',\'' + p[1] + '\',true)">' + p[0] + '</button>'; }).join('') + '</span></label>' : '') +
      '<div class="hsa-imgbox hsa-full"><b style="font-size:.8rem;">' + (poster ? 'Picha ya bango (nzima)' : 'Picha kuu ya bidhaa') + '</b><br>' + (img1 ? '<img src="' + E(img1) + '" alt="">' : '<div style="color:#999;font-size:.8rem;margin:8px 0;">Hakuna picha bado</div>') +
        '<button type="button" class="btn btn-primary" onclick="hsaPick(' + i + ',1)">🖼 ' + (img1 ? 'Badilisha Picha' : 'Weka Picha') + '</button> ' + (img1 ? '<button type="button" class="btn btn-ghost" onclick="hsaClearImg(' + i + ',1)">🗑 Ondoa</button>' : '') +
        '<div style="font-size:.7rem;color:var(--ink-soft);margin-top:6px;">' + (poster ? 'Bora: picha pana (16:9) yenye kitu muhimu katikati. Inabanwa kiotomatiki.' : 'Bora: picha ya mraba, bidhaa katikati. Inabanwa kiotomatiki.') + '</div></div>' +
      (poster ? '' : '<div class="hsa-imgbox hsa-full"><b style="font-size:.8rem;">Picha ya pili ndogo (hiari)</b><br>' + (img2 ? '<img src="' + E(img2) + '" alt="">' : '') + '<button type="button" class="btn btn-ghost" onclick="hsaPick(' + i + ',2)">🖼 ' + (img2 ? 'Badilisha' : 'Weka') + ' picha ya pili</button> ' + (img2 ? '<button type="button" class="btn btn-ghost" onclick="hsaClearImg(' + i + ',2)">🗑 Ondoa</button>' : '') + '</div>') +
      '<div class="hsa-full" style="display:flex;gap:8px;flex-wrap:wrap;"><button class="btn btn-ghost" onclick="hsaDup(' + i + ')">📋 Nakili slaidi hii</button><button class="btn btn-ghost" style="color:#b23a3a;border-color:#b23a3a;" onclick="hsaDel(' + i + ')">🗑 Futa slaidi</button></div>' +
      '</div>';
  }
  function prodOptions(prods, sel, q) {
    q = String(q || '').toLowerCase();
    return prods.filter(function (p) { return !q || String(p.name).toLowerCase().indexOf(q) > -1 || String(p.id) === q; }).slice(0, 200)
      .map(function (p) { return '<option value="' + p.id + '"' + (String(p.id) === String(sel) ? ' selected' : '') + '>' + E(p.name) + ' (#' + p.id + ')</option>'; }).join('');
  }

  /* ---------- vitendo (global kwa onclick) ---------- */
  window.hsaCfg = function (k, v) { hsa.cfg[k] = v; };
  window.hsaSet = function (i, k, v, redraw) { var s = hsa.cfg.slides[i]; if (!s) return; s[k] = v; if (k === 'linkType' && v === 'product') s.link = ''; if (redraw) draw(); };
  window.hsaFilter = function (i, q) { var sel = document.getElementById('hsaProdSel' + i); if (!sel) return; var prods = (typeof allAdminProducts === 'function' ? allAdminProducts() : PRODUCTS).slice().sort(function (a, b) { return String(a.name).localeCompare(String(b.name)); }); sel.innerHTML = prodOptions(prods, hsa.cfg.slides[i].link, q); };
  window.hsaAdd = function () { if (hsa.cfg.slides.length >= MAX_SLIDES) { status('⚠️ Kiwango cha juu ni slaidi ' + MAX_SLIDES + '.', '#b23a3a'); return; } hsa.cfg.slides.push(blank()); hsa.open = hsa.cfg.slides.length - 1; draw(); };
  window.hsaSeed = function () { hsa.cfg.slides = seedDefaults(); hsa.open = -1; draw(); status('📥 Slaidi 3 za sasa zimeletwa — zihariri unavyotaka kisha bonyeza 💾 Hifadhi.', 'var(--green-deep)'); };
  window.hsaEdit = function (i) { hsa.open = hsa.open === i ? -1 : i; draw(); };
  window.hsaToggle = function (i) { hsa.cfg.slides[i].on = !hsa.cfg.slides[i].on; draw(); };
  window.hsaMove = function (i, d) { var a = hsa.cfg.slides, j = i + d; if (j < 0 || j >= a.length) return; var t = a[i]; a[i] = a[j]; a[j] = t; if (hsa.open === i) hsa.open = j; else if (hsa.open === j) hsa.open = i; draw(); };
  window.hsaDup = function (i) { if (hsa.cfg.slides.length >= MAX_SLIDES) return; var c = JSON.parse(JSON.stringify(hsa.cfg.slides[i])); c.id = rid(); hsa.cfg.slides.splice(i + 1, 0, c); hsa.open = i + 1; draw(); };
  window.hsaDel = function (i) { if (!confirm('Futa slaidi hii?')) return; var s = hsa.cfg.slides[i]; [s.img, s.img2].forEach(function (x) { if (x) hsa.removed.push(x); }); hsa.cfg.slides.splice(i, 1); hsa.open = -1; draw(); };
  window.hsaClearImg = function (i, which) { var s = hsa.cfg.slides[i]; var k = which === 2 ? 'img2' : 'img'; if (s[k]) hsa.removed.push(s[k]); s[k] = ''; s[k + 'v'] = 0; s[k + 'Url'] = ''; draw(); };
  window.hsaPick = function (i, which) {
    var inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*';
    inp.onchange = async function () {
      var f = inp.files && inp.files[0]; if (!f) return;
      status('⏳ Inabana picha...');
      var s = hsa.cfg.slides[i], poster = s.layout === 'poster';
      var small = which === 2;
      var dim = poster ? 1400 : (small ? 500 : 900), target = poster ? 230 * 1024 : (small ? 60 * 1024 : 120 * 1024);
      try {
        var out = (typeof compressImageFile === 'function') ? await compressImageFile(f, dim, target) : f;
        var data = await new Promise(function (res, rej) { var r = new FileReader(); r.onload = function () { res(r.result); }; r.onerror = rej; r.readAsDataURL(out); });
        if (data.length > 700 * 1024) { status('⚠️ Picha bado kubwa mno baada ya kubana. Jaribu picha ndogo zaidi.', '#b23a3a'); return; }
        var k = which === 2 ? 'img2' : 'img';
        if (s[k]) hsa.removed.push(s[k]);
        var id = rid(); hsa.pending[id] = data; s[k] = id; s[k + 'v'] = Date.now(); s[k + 'Url'] = '';
        status('✅ Picha imewekwa — bonyeza 💾 Hifadhi ili ionekane kwa wateja.', 'var(--green-deep)');
        draw();
      } catch (e) { console.error(e); status('⚠️ Picha imeshindwa kusomwa. Jaribu nyingine.', '#b23a3a'); }
    };
    inp.click();
  };
  window.hsaSave = async function () {
    if (hsa.busy) return;
    if (typeof AHS_CLOUD_READY === 'undefined' || !AHS_CLOUD_READY) { status('⚠️ Firebase haijaunganishwa — haiwezi kuhifadhi kwa wateja.', '#b23a3a'); return; }
    if (typeof ahsCloudAdminOK !== 'undefined' && !ahsCloudAdminOK) { status('⚠️ Hujaingia rasmi (Auth). Toka kisha ingia tena kwa email ya admin.', '#b23a3a'); return; }
    hsa.busy = true; status('⏳ Inahifadhi...');
    try {
      var used = {};
      hsa.cfg.slides.forEach(function (s) { if (s.img) used[s.img] = 1; if (s.img2) used[s.img2] = 1; });
      var ids = Object.keys(hsa.pending).filter(function (id) { return used[id]; });
      for (var n = 0; n < ids.length; n++) {
        var ok = await cloudSaveHeroImage(ids[n], hsa.pending[ids[n]]);
        if (!ok) { status('❌ Picha imeshindwa kuhifadhiwa. Angalia mtandao/ruhusa kisha jaribu tena.', '#b23a3a'); hsa.busy = false; return; }
      }
      var clean = {
        enabled: !!hsa.cfg.enabled, effect: hsa.cfg.effect || 'mix', interval: Number(hsa.cfg.interval) || 6, updated: Date.now(),
        slides: hsa.cfg.slides.map(function (s) {
          return { id: s.id, on: s.on !== false, layout: s.layout === 'poster' ? 'poster' : 'product', theme: s.theme || 'wine', fx: s.fx || 'auto',
            tag: s.tag || '', white: s.white || '', gold: s.gold || '', text: s.text || '', btn: s.btn || '', linkType: s.linkType || 'none', link: String(s.link || ''),
            img: s.img || '', imgv: s.imgv || 0, img2: s.img2 || '', img2v: s.img2v || 0, imgUrl: s.imgUrl || '', img2Url: s.img2Url || '' };
        })
      };
      var saved = await cloudSaveHeroSlider(clean);
      if (!saved) { status('❌ Imeshindwa kuhifadhi mipangilio. Jaribu tena.', '#b23a3a'); hsa.busy = false; return; }
      ids.forEach(function (id) { delete hsa.pending[id]; });
      hsa.removed.filter(function (id) { return !used[id]; }).forEach(function (id) { if (typeof cloudDeleteHeroImage === 'function') cloudDeleteHeroImage(id); });
      hsa.removed = [];
      status('✅ Imehifadhiwa — wateja wataona slaidi mpya papo hapo.', 'var(--green-deep)');
    } catch (e) { console.error(e); status('❌ Hitilafu: ' + (e && e.message || e), '#b23a3a'); }
    hsa.busy = false;
  };

  // unganisha na mfumo wa tab wa admin.js
  if (typeof ADMIN_TAB_RENDERERS !== 'undefined') ADMIN_TAB_RENDERERS.slaidi = function () { return window.renderSlaidiTab(); };
})();
