// Agnes Herbal Supplements — Slaidi za mwanzo zinazohaririwa na admin (storefront)
// ============================================================================
// Admin anatengeneza slaidi kwenye admin.html → tab "🖼 Slaidi za Mwanzo". Zinahifadhiwa Firestore
// (meta/heroSlider + meta/heroImg_<id>). Hapa tunazisoma papo hapo (live) na kuzionyesha kwenye #hsTrack.
// Hakuna slaidi za admin = slaidi 3 za kawaida za index.html zinabaki kama zilivyo.
(function () {
  'use strict';
  var LS = 'ahs_hero_cfg';
  var track = null, defaultHTML = null, customActive = false, lastKey = '';

  function safeUrl(u) {
    u = String(u || '').trim();
    if (!u) return '';
    if (/^(https?:\/\/|\/|#|tel:|mailto:)/i.test(u)) return u;
    if (/^wa\.me\//i.test(u)) return 'https://' + u;
    return '';
  }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  // Picha: URL thabiti ya Function (/img/hero/<id>.jpg?v=...). Ikishindwa (mf. Functions hazipo), tunasoma
  // moja kwa moja kutoka Firestore kama data URL.
  function setImg(img, id, v, url) {
    img.alt = img.alt || '';
    img.decoding = 'async';
    if (!id && url) { img.src = '/' + String(url).replace(/^\/+/, ''); return; } // picha ya kawaida ya duka (images/pXXX.jpg)
    img.src = '/img/hero/' + encodeURIComponent(id) + '.jpg?v=' + (v || 0);
    var tried = false;
    img.onerror = function () {
      if (tried) return; tried = true;
      if (typeof cloudGetHeroImage === 'function') {
        cloudGetHeroImage(id).then(function (d) { if (d) img.src = d; });
      }
    };
  }
  function buildButton(sl) {
    var label = String(sl.btn || '').trim();
    if (!label || sl.linkType === 'none') return null;
    var a = el('a', 'btn-glass', label);
    if (sl.linkType === 'product' && /^\d+$/.test(String(sl.link))) {
      var pid = parseInt(sl.link, 10);
      a.href = '#bidhaa';
      a.addEventListener('click', function (e) { if (window.openProduct) { e.preventDefault(); window.openProduct(pid); } });
    } else {
      var u = safeUrl(sl.link);
      if (!u) return null;
      a.href = u;
      if (/^https?:\/\//i.test(u) && u.indexOf(location.origin) !== 0) { a.target = '_blank'; a.rel = 'noopener'; }
    }
    return a;
  }
  function buildSlide(sl) {
    var theme = String(sl.theme || 'wine').replace(/[^a-z]/g, '');
    var root = el('div', 'hs-slide hs3d s-' + theme);
    if (sl.fx && sl.fx !== 'auto') root.dataset.fx = String(sl.fx).replace(/[^a-zA-Z]/g, '');
    if (sl.layout === 'poster') {
      root.classList.add('hs-poster');
      var im = el('img', 'hs-poster-img');
      im.alt = sl.white || sl.tag || '';
      if (sl.img || sl.imgUrl) setImg(im, sl.img, sl.imgv, sl.imgUrl);
      root.appendChild(im);
      root.appendChild(el('div', 'hs-poster-shade'));
      var hasText = sl.tag || sl.white || sl.gold || sl.text || sl.btn;
      var wrap = el('div', 'wrap hs-inner hs-poster-text');
      if (hasText) {
        if (sl.tag) wrap.appendChild(el('span', 'hs-tag', sl.tag));
        if (sl.white || sl.gold) {
          var h = el('h2');
          if (sl.white) h.appendChild(el('span', 'h3-white', sl.white));
          if (sl.gold) h.appendChild(el('span', 'h3-gold', sl.gold));
          wrap.appendChild(h);
        }
        if (sl.text) wrap.appendChild(el('p', '', sl.text));
        var b1 = buildButton(sl); if (b1) wrap.appendChild(b1);
        root.appendChild(wrap);
      }
      // Bango bila maandishi: picha nzima inabofyeka ikiwa kuna kiungo
      if (!hasText && sl.linkType !== 'none' && (sl.link || '') !== '') {
        var whole = buildButton({ btn: 'x', link: sl.link, linkType: sl.linkType });
        if (whole) { whole.className = 'hs-poster-link'; whole.textContent = ''; whole.setAttribute('aria-label', sl.white || 'Fungua'); root.appendChild(whole); }
      }
      return root;
    }
    // Aina ya "Bidhaa": maandishi kushoto, picha kulia
    root.appendChild(el('div', 'h3-bokeh'));
    var grid = el('div', 'wrap hs-inner h3-grid');
    var tx = el('div', 'h3-text');
    if (sl.tag) tx.appendChild(el('span', 'hs-tag', sl.tag));
    if (sl.white || sl.gold) {
      var h2 = el('h2');
      if (sl.white) h2.appendChild(el('span', 'h3-white', sl.white));
      if (sl.gold) h2.appendChild(el('span', 'h3-gold', sl.gold));
      tx.appendChild(h2);
    }
    if (sl.text) tx.appendChild(el('p', '', sl.text));
    var b2 = buildButton(sl); if (b2) tx.appendChild(b2);
    grid.appendChild(tx);
    if (sl.img || sl.img2 || sl.imgUrl || sl.img2Url) {
      var stage = el('div', 'h3-stage');
      stage.setAttribute('data-parallax', '');
      if (sl.img || sl.imgUrl) { var m = el('img', 'h3-prod h3-main'); m.width = 300; m.height = 300; m.alt = sl.white || ''; setImg(m, sl.img, sl.imgv, sl.imgUrl); stage.appendChild(m); }
      if (sl.img2 || sl.img2Url) { var s2 = el('img', 'h3-prod h3-side'); s2.width = 180; s2.height = 180; s2.alt = ''; setImg(s2, sl.img2, sl.img2v, sl.img2Url); stage.appendChild(s2); }
      ['s1', 's2', 's3'].forEach(function (c) { stage.appendChild(el('i', 'h3-spark ' + c)); });
      grid.appendChild(stage);
    } else {
      grid.classList.add('hs-noimg');
    }
    root.appendChild(grid);
    return root;
  }

  function restoreDefault(conf) {
    if (customActive && track && defaultHTML !== null) {
      track.innerHTML = defaultHTML;
      customActive = false; lastKey = '';
      if (window.hsApplyConfig) window.hsApplyConfig(conf, true);
    } else if (window.hsApplyConfig) {
      window.hsApplyConfig(conf, false);
    }
  }
  function apply(cfg) {
    track = track || document.getElementById('hsTrack');
    if (!track) return;
    if (defaultHTML === null) defaultHTML = track.innerHTML;
    var conf = { effect: (cfg && cfg.effect) || 'mix', interval: (cfg && cfg.interval) || 6 };
    var slides = (cfg && cfg.enabled !== false && Array.isArray(cfg.slides)) ? cfg.slides.filter(function (s) { return s && s.on !== false; }) : [];
    if (!slides.length) { restoreDefault(conf); return; }
    var key = JSON.stringify([cfg.updated, slides.length, conf]);
    if (key === lastKey && customActive) return;
    lastKey = key;
    track.innerHTML = '';
    slides.forEach(function (sl) { try { track.appendChild(buildSlide(sl)); } catch (e) { console.warn('[hero] slaidi imeshindwa', e); } });
    customActive = true;
    if (window.hsApplyConfig) window.hsApplyConfig(conf, true);
  }

  // 1) Haraka: onyesha toleo la mwisho lililohifadhiwa kwenye kifaa (hakuna kusubiri mtandao)
  try { var cached = JSON.parse(localStorage.getItem(LS) || 'null'); if (cached) apply(cached); } catch (e) { /* ignore */ }
  // 2) Live: Firestore. Firebase inapakia kwa njia isiyozuia (index.html), kwa hiyo tunasubiri tukio 'ahsCloudReady'.
  var listening = false;
  function listen() {
    if (listening || typeof cloudListenHeroSlider !== 'function') return;
    listening = true;
    cloudListenHeroSlider(function (cfg) {
      try { if (cfg) localStorage.setItem(LS, JSON.stringify(cfg)); else localStorage.removeItem(LS); } catch (e) { /* ignore */ }
      apply(cfg);
    });
  }
  document.addEventListener('ahsCloudReady', listen);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(listen, 0); });
  else setTimeout(listen, 0);
})();
