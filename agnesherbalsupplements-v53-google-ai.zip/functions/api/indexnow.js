// Route: POST /api/indexnow — inaarifu Bing/Yandex/n.k. (IndexNow) kuhusu bidhaa mpya/zilizobadilika.
// Inaitwa na admin kila unaposave/kufuta bidhaa. Inatuma URL za tovuti hii TU (za nje zinakataliwa).
import { fetchCustomProducts, productSlug, SITE, INDEXNOW_KEY } from '../_lib/seo.js';

export async function onRequestPost({ request }) {
  let urls = [];
  try { const b = await request.json(); if (Array.isArray(b && b.urls)) urls = b.urls; } catch (e) { /* tumia orodha ya kawaida */ }
  urls = urls.filter(u => typeof u === 'string' && u.startsWith(SITE + '/')).slice(0, 500);
  if (!urls.length) {
    let custom = [];
    try { custom = await fetchCustomProducts(); } catch (e) { custom = []; }
    urls = [`${SITE}/`, `${SITE}/orodha/`, `${SITE}/je-ipo/`].concat(custom.filter(p => p && p.name).map(p => `${SITE}/products/${productSlug(p)}`));
  }
  const res = await fetch('https://api.indexnow.org/indexnow', {
    method: 'POST', headers: { 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify({ host: new URL(SITE).host, key: INDEXNOW_KEY, keyLocation: `${SITE}/${INDEXNOW_KEY}.txt`, urlList: urls }),
  });
  return new Response(JSON.stringify({ ok: res.ok, status: res.status, submitted: urls.length }), {
    status: 200, headers: { 'Content-Type': 'application/json' } });
}
